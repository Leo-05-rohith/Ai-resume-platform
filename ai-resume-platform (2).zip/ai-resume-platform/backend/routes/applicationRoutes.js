const express = require('express');
const router = express.Router();
const {
  applyToJob,
  getMyApplications,
  getAllApplications,
  updateApplicationStatus,
} = require('../controllers/applicationController');
const { protect } = require('../middleware/auth');
const { isAdmin } = require('../middleware/admin');

router.post('/', protect, applyToJob);
router.get('/me', protect, getMyApplications);
router.get('/', protect, isAdmin, getAllApplications);
router.put('/:id/status', protect, isAdmin, updateApplicationStatus);

module.exports = router;

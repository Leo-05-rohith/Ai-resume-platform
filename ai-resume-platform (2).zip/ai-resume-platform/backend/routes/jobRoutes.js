const express = require('express');
const router = express.Router();
const { listJobs, getJob, createJob, updateJob, deleteJob } = require('../controllers/jobController');
const { protect } = require('../middleware/auth');
const { isAdmin } = require('../middleware/admin');

router.get('/', listJobs);
router.get('/:id', getJob);
router.post('/', protect, isAdmin, createJob);
router.put('/:id', protect, isAdmin, updateJob);
router.delete('/:id', protect, isAdmin, deleteJob);

module.exports = router;

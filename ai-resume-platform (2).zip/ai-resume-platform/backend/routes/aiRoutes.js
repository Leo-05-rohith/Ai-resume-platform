const express = require('express');
const router = express.Router();
const { generateSummary, getRecommendations, matchSingleJob } = require('../controllers/aiController');
const { protect } = require('../middleware/auth');

router.post('/improve-summary', protect, generateSummary);
router.get('/recommendations', protect, getRecommendations);
router.post('/match-job/:jobId', protect, matchSingleJob);

module.exports = router;

const express = require('express');
const router = express.Router();
const { getMyResume, upsertMyResume, getResumeById } = require('../controllers/resumeController');
const { protect } = require('../middleware/auth');

router.get('/me', protect, getMyResume);
router.put('/me', protect, upsertMyResume);
router.get('/:id', protect, getResumeById);

module.exports = router;

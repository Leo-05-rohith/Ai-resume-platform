const mongoose = require('mongoose');

const ApplicationSchema = new mongoose.Schema(
  {
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    job_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Job', required: true },
    resume_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Resume' },
    status: {
      type: String,
      enum: ['applied', 'under_review', 'shortlisted', 'rejected', 'hired'],
      default: 'applied',
    },
    applied_at: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

ApplicationSchema.index({ user_id: 1, job_id: 1 }, { unique: true });

module.exports = mongoose.model('Application', ApplicationSchema);

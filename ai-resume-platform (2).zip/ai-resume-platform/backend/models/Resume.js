const mongoose = require('mongoose');

const EducationSchema = new mongoose.Schema(
  {
    institution: String,
    degree: String,
    field: String,
    startYear: String,
    endYear: String,
  },
  { _id: false }
);

const ExperienceSchema = new mongoose.Schema(
  {
    company: String,
    role: String,
    startDate: String,
    endDate: String,
    description: String,
  },
  { _id: false }
);

const ProjectSchema = new mongoose.Schema(
  {
    title: String,
    description: String,
    techStack: String,
    link: String,
  },
  { _id: false }
);

const ResumeSchema = new mongoose.Schema(
  {
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    fullName: String,
    contact: {
      email: String,
      phone: String,
      location: String,
      linkedin: String,
      github: String,
    },
    summary: { type: String, default: '' },
    education: [EducationSchema],
    experience: [ExperienceSchema],
    projects: [ProjectSchema],
    skills: [{ type: String }],
  },
  { timestamps: true }
);

module.exports = mongoose.model('Resume', ResumeSchema);

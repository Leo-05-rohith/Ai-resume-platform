const { improveSummary, matchResumeToJob } = require('../services/aiService');
const Resume = require('../models/Resume');
const Job = require('../models/Job');

// @route POST /api/ai/improve-summary
const generateSummary = async (req, res) => {
  try {
    const resume = await Resume.findOne({ user_id: req.user._id });
    if (!resume) return res.status(400).json({ message: 'Create your resume details first' });

    const summary = await improveSummary({
      skills: resume.skills,
      experience: resume.experience,
      projects: resume.projects,
      draftSummary: req.body.draftSummary || resume.summary,
    });

    res.json({ summary });
  } catch (err) {
    res.status(500).json({ message: `AI generation failed: ${err.message}` });
  }
};

// @route GET /api/ai/recommendations
// Matches the logged-in user's resume against all jobs and returns them ranked by score.
const getRecommendations = async (req, res) => {
  try {
    const resume = await Resume.findOne({ user_id: req.user._id });
    if (!resume) return res.status(400).json({ message: 'Create your resume details first' });

    const jobs = await Job.find().sort({ createdAt: -1 }).limit(20);

    const results = await Promise.all(
      jobs.map(async (job) => {
        const match = await matchResumeToJob({
          resumeSkills: resume.skills,
          resumeSummary: resume.summary,
          job,
        });
        return { job, match };
      })
    );

    results.sort((a, b) => (b.match.score || 0) - (a.match.score || 0));
    res.json({ recommendations: results });
  } catch (err) {
    res.status(500).json({ message: `AI recommendation failed: ${err.message}` });
  }
};

// @route POST /api/ai/match-job/:jobId  - match against one specific job
const matchSingleJob = async (req, res) => {
  try {
    const resume = await Resume.findOne({ user_id: req.user._id });
    if (!resume) return res.status(400).json({ message: 'Create your resume details first' });

    const job = await Job.findById(req.params.jobId);
    if (!job) return res.status(404).json({ message: 'Job not found' });

    const match = await matchResumeToJob({
      resumeSkills: resume.skills,
      resumeSummary: resume.summary,
      job,
    });

    res.json({ match });
  } catch (err) {
    res.status(500).json({ message: `AI matching failed: ${err.message}` });
  }
};

module.exports = { generateSummary, getRecommendations, matchSingleJob };

const Resume = require('../models/Resume');

// @route GET /api/resumes/me
const getMyResume = async (req, res) => {
  try {
    let resume = await Resume.findOne({ user_id: req.user._id });
    if (!resume) {
      resume = await Resume.create({ user_id: req.user._id, fullName: req.user.name });
    }
    res.json({ resume });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// @route PUT /api/resumes/me  (create-or-update, full resume payload)
const upsertMyResume = async (req, res) => {
  try {
    const { fullName, contact, summary, education, experience, projects, skills } = req.body;

    const resume = await Resume.findOneAndUpdate(
      { user_id: req.user._id },
      {
        $set: {
          fullName: fullName ?? req.user.name,
          contact: contact ?? {},
          summary: summary ?? '',
          education: education ?? [],
          experience: experience ?? [],
          projects: projects ?? [],
          skills: skills ?? [],
        },
      },
      { new: true, upsert: true, setDefaultsOnInsert: true }
    );

    res.json({ resume });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// @route GET /api/resumes/:id  (admin or owner)
const getResumeById = async (req, res) => {
  try {
    const resume = await Resume.findById(req.params.id);
    if (!resume) return res.status(404).json({ message: 'Resume not found' });
    if (String(resume.user_id) !== String(req.user._id) && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to view this resume' });
    }
    res.json({ resume });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = { getMyResume, upsertMyResume, getResumeById };

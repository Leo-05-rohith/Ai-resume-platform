const Application = require('../models/Application');
const Resume = require('../models/Resume');
const Job = require('../models/Job');

// @route POST /api/applications  { job_id }
const applyToJob = async (req, res) => {
  try {
    const { job_id } = req.body;
    const job = await Job.findById(job_id);
    if (!job) return res.status(404).json({ message: 'Job not found' });

    const resume = await Resume.findOne({ user_id: req.user._id });
    if (!resume) return res.status(400).json({ message: 'Please complete your resume before applying' });

    const existing = await Application.findOne({ user_id: req.user._id, job_id });
    if (existing) return res.status(409).json({ message: 'You have already applied to this job' });

    const application = await Application.create({
      user_id: req.user._id,
      job_id,
      resume_id: resume._id,
    });

    res.status(201).json({ application });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// @route GET /api/applications/me
const getMyApplications = async (req, res) => {
  try {
    const applications = await Application.find({ user_id: req.user._id })
      .populate('job_id')
      .sort({ createdAt: -1 });
    res.json({ applications });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// @route GET /api/applications  (admin - all applications, optional ?job_id=)
const getAllApplications = async (req, res) => {
  try {
    const filter = {};
    if (req.query.job_id) filter.job_id = req.query.job_id;
    const applications = await Application.find(filter)
      .populate('job_id')
      .populate('user_id', 'name email')
      .sort({ createdAt: -1 });
    res.json({ applications });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// @route PUT /api/applications/:id/status  (admin)  { status }
const updateApplicationStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const application = await Application.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    );
    if (!application) return res.status(404).json({ message: 'Application not found' });
    res.json({ application });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = { applyToJob, getMyApplications, getAllApplications, updateApplicationStatus };

const Job = require('../models/Job');

// @route GET /api/jobs?search=&location=&skill=&jobType=
const listJobs = async (req, res) => {
  try {
    const { search, location, skill, jobType, page = 1, limit = 10 } = req.query;
    const query = {};

    if (search) query.$text = { $search: search };
    if (location) query.location = { $regex: location, $options: 'i' };
    if (jobType) query.jobType = jobType;
    if (skill) query.skills = { $regex: skill, $options: 'i' };

    const skip = (Number(page) - 1) * Number(limit);
    const [jobs, total] = await Promise.all([
      Job.find(query).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      Job.countDocuments(query),
    ]);

    res.json({ jobs, total, page: Number(page), pages: Math.ceil(total / Number(limit)) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// @route GET /api/jobs/:id
const getJob = async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);
    if (!job) return res.status(404).json({ message: 'Job not found' });
    res.json({ job });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// @route POST /api/jobs  (admin)
const createJob = async (req, res) => {
  try {
    const { title, company, location, description, skills, jobType } = req.body;
    if (!title || !company || !description) {
      return res.status(400).json({ message: 'Title, company and description are required' });
    }
    const job = await Job.create({
      title,
      company,
      location,
      description,
      skills: skills || [],
      jobType,
      postedBy: req.user._id,
    });
    res.status(201).json({ job });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// @route PUT /api/jobs/:id  (admin)
const updateJob = async (req, res) => {
  try {
    const job = await Job.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!job) return res.status(404).json({ message: 'Job not found' });
    res.json({ job });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// @route DELETE /api/jobs/:id  (admin)
const deleteJob = async (req, res) => {
  try {
    const job = await Job.findByIdAndDelete(req.params.id);
    if (!job) return res.status(404).json({ message: 'Job not found' });
    res.json({ message: 'Job deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = { listJobs, getJob, createJob, updateJob, deleteJob };

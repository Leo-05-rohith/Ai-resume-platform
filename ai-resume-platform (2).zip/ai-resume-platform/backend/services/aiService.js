/**
 * AI Service
 * Wraps calls to the OpenAI API (or any OpenAI-compatible endpoint).
 * Centralizing this here means the rest of the app never talks to the AI
 * provider directly, and the provider/model can be swapped via .env only.
 */
const OpenAI = require('openai');

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';

/**
 * Generate/improve a professional resume summary based on the user's
 * existing details (skills, experience, projects, and optionally a draft).
 */
async function improveSummary({ skills = [], experience = [], projects = [], draftSummary = '' }) {
  const prompt = `You are an expert resume writer. Write a concise, impactful, ATS-friendly
professional summary (3-4 sentences, no bullet points) for a candidate with:

Skills: ${skills.join(', ') || 'N/A'}
Experience: ${JSON.stringify(experience) || 'N/A'}
Projects: ${JSON.stringify(projects) || 'N/A'}
${draftSummary ? `Existing draft to improve: "${draftSummary}"` : ''}

Return only the final summary text, with no preamble or quotation marks.`;

  const response = await client.chat.completions.create({
    model: MODEL,
    messages: [{ role: 'user', content: prompt }],
    temperature: 0.6,
    max_tokens: 300,
  });

  return response.choices[0].message.content.trim();
}

/**
 * Compute a match score + explanation between a resume's skills and a
 * job description's required skills using the AI model.
 */
async function matchResumeToJob({ resumeSkills = [], resumeSummary = '', job }) {
  const prompt = `You are a job-matching assistant. Compare the candidate profile to the job
and respond ONLY with strict JSON (no markdown, no code fences) in this exact shape:
{"score": <integer 0-100>, "matchedSkills": [<strings>], "missingSkills": [<strings>], "reason": "<1-2 sentence explanation>"}

Candidate skills: ${resumeSkills.join(', ') || 'N/A'}
Candidate summary: ${resumeSummary || 'N/A'}

Job title: ${job.title}
Job required skills: ${(job.skills || []).join(', ') || 'N/A'}
Job description: ${job.description}`;

  const response = await client.chat.completions.create({
    model: MODEL,
    messages: [{ role: 'user', content: prompt }],
    temperature: 0.3,
    max_tokens: 400,
  });

  const raw = response.choices[0].message.content.trim();
  try {
    const cleaned = raw.replace(/```json|```/g, '').trim();
    return JSON.parse(cleaned);
  } catch (e) {
    // Fallback: naive keyword overlap if the model didn't return valid JSON
    const matched = (job.skills || []).filter((s) =>
      resumeSkills.map((r) => r.toLowerCase()).includes(s.toLowerCase())
    );
    const missing = (job.skills || []).filter((s) => !matched.includes(s));
    const score = job.skills && job.skills.length ? Math.round((matched.length / job.skills.length) * 100) : 0;
    return { score, matchedSkills: matched, missingSkills: missing, reason: 'Computed via keyword overlap fallback.' };
  }
}

module.exports = { improveSummary, matchResumeToJob };

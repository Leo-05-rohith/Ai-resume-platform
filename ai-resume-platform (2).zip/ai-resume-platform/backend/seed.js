/**
 * Optional helper script to seed the database with a few sample job postings
 * for local testing / demo purposes.
 * Usage: node seed.js
 */
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('./config/db');
const Job = require('./models/Job');

const sampleJobs = [
  {
    title: 'Frontend Developer (React)',
    company: 'TechNova Solutions',
    location: 'Bengaluru, India',
    description:
      'Build responsive, accessible UIs with React and collaborate with backend engineers to ship features end to end.',
    skills: ['React', 'JavaScript', 'HTML', 'CSS', 'Git'],
    jobType: 'Full-time',
  },
  {
    title: 'Backend Engineer (Node.js)',
    company: 'CloudWorks Inc',
    location: 'Remote',
    description:
      'Design and maintain REST APIs, work with MongoDB, and integrate third-party services including AI APIs.',
    skills: ['Node.js', 'Express', 'MongoDB', 'REST APIs', 'JWT'],
    jobType: 'Full-time',
  },
  {
    title: 'Full Stack Intern',
    company: 'Startify Labs',
    location: 'Hyderabad, India',
    description:
      'Work across the stack building features for a fast-growing SaaS product, with mentorship from senior engineers.',
    skills: ['JavaScript', 'React', 'Node.js', 'MongoDB'],
    jobType: 'Internship',
  },
  {
    title: 'AI/ML Application Engineer',
    company: 'Nexora AI',
    location: 'Remote',
    description:
      'Integrate LLM APIs into production applications, design prompts, and build evaluation pipelines for AI features.',
    skills: ['Python', 'OpenAI API', 'Node.js', 'Prompt Engineering'],
    jobType: 'Full-time',
  },
  {
    title: 'Database Administrator',
    company: 'DataVault Systems',
    location: 'Pune, India',
    description:
      'Own schema design, indexing strategy, and performance tuning for MongoDB and MySQL databases.',
    skills: ['MongoDB', 'MySQL', 'Database Design', 'SQL'],
    jobType: 'Contract',
  },
];

(async () => {
  await connectDB();
  await Job.deleteMany({});
  await Job.insertMany(sampleJobs);
  console.log(`Seeded ${sampleJobs.length} sample jobs.`);
  await mongoose.disconnect();
  process.exit(0);
})();

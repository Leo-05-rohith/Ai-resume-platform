import React from 'react';

const ResumePreview = ({ resume }) => {
  if (!resume) return null;
  return (
    <div className="resume-preview" id="resume-preview">
      <h2>{resume.fullName || 'Your Name'}</h2>
      <p className="resume-contact">
        {[resume.contact?.email, resume.contact?.phone, resume.contact?.location, resume.contact?.linkedin, resume.contact?.github]
          .filter(Boolean)
          .join(' | ')}
      </p>

      {resume.summary && (
        <section>
          <h3>Professional Summary</h3>
          <p>{resume.summary}</p>
        </section>
      )}

      {resume.skills?.length > 0 && (
        <section>
          <h3>Skills</h3>
          <p>{resume.skills.join(', ')}</p>
        </section>
      )}

      {resume.experience?.length > 0 && (
        <section>
          <h3>Experience</h3>
          {resume.experience.map((exp, i) => (
            <div key={i} className="resume-item">
              <strong>{exp.role}</strong> — {exp.company} ({exp.startDate} to {exp.endDate || 'Present'})
              <p>{exp.description}</p>
            </div>
          ))}
        </section>
      )}

      {resume.projects?.length > 0 && (
        <section>
          <h3>Projects</h3>
          {resume.projects.map((proj, i) => (
            <div key={i} className="resume-item">
              <strong>{proj.title}</strong> {proj.techStack ? `(${proj.techStack})` : ''}
              <p>{proj.description}</p>
              {proj.link && <a href={proj.link} target="_blank" rel="noreferrer">{proj.link}</a>}
            </div>
          ))}
        </section>
      )}

      {resume.education?.length > 0 && (
        <section>
          <h3>Education</h3>
          {resume.education.map((edu, i) => (
            <div key={i} className="resume-item">
              <strong>{edu.degree}</strong> in {edu.field} — {edu.institution} ({edu.startYear} - {edu.endYear})
            </div>
          ))}
        </section>
      )}
    </div>
  );
};

export default ResumePreview;

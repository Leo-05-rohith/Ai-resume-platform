import React, { useEffect, useState } from 'react';
import api from '../api/axios';
import ResumePreview from '../components/ResumePreview';

const emptyEducation = { institution: '', degree: '', field: '', startYear: '', endYear: '' };
const emptyExperience = { company: '', role: '', startDate: '', endDate: '', description: '' };
const emptyProject = { title: '', description: '', techStack: '', link: '' };

const ResumeBuilder = () => {
  const [resume, setResume] = useState(null);
  const [skillInput, setSkillInput] = useState('');
  const [saving, setSaving] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    api.get('/resumes/me').then((res) => setResume(res.data.resume));
  }, []);

  if (!resume) return <div className="page-center">Loading resume...</div>;

  const update = (field, value) => setResume({ ...resume, [field]: value });
  const updateContact = (field, value) => setResume({ ...resume, contact: { ...resume.contact, [field]: value } });

  const addItem = (field, template) => update(field, [...(resume[field] || []), { ...template }]);
  const updateItem = (field, idx, key, value) => {
    const items = [...resume[field]];
    items[idx] = { ...items[idx], [key]: value };
    update(field, items);
  };
  const removeItem = (field, idx) => update(field, resume[field].filter((_, i) => i !== idx));

  const addSkill = () => {
    if (skillInput.trim()) {
      update('skills', [...(resume.skills || []), skillInput.trim()]);
      setSkillInput('');
    }
  };
  const removeSkill = (idx) => update('skills', resume.skills.filter((_, i) => i !== idx));

  const handleSave = async () => {
    setSaving(true);
    setMessage('');
    try {
      const res = await api.put('/resumes/me', resume);
      setResume(res.data.resume);
      setMessage('Resume saved successfully.');
    } catch (err) {
      setMessage(err.response?.data?.message || 'Failed to save resume');
    } finally {
      setSaving(false);
    }
  };

  const handleAiImprove = async () => {
    setAiLoading(true);
    setMessage('');
    try {
      await api.put('/resumes/me', resume); // persist latest data first
      const res = await api.post('/ai/improve-summary', { draftSummary: resume.summary });
      update('summary', res.data.summary);
      setMessage('AI-improved summary generated.');
    } catch (err) {
      setMessage(err.response?.data?.message || 'AI generation failed');
    } finally {
      setAiLoading(false);
    }
  };

  const handleDownload = () => {
    window.print();
  };

  return (
    <div className="page resume-builder">
      <h1>Resume Builder</h1>
      {message && <p className="info-text">{message}</p>}

      <div className="builder-grid">
        <div className="builder-form">
          <section>
            <h3>Basic Info</h3>
            <input placeholder="Full Name" value={resume.fullName || ''} onChange={(e) => update('fullName', e.target.value)} />
            <input placeholder="Email" value={resume.contact?.email || ''} onChange={(e) => updateContact('email', e.target.value)} />
            <input placeholder="Phone" value={resume.contact?.phone || ''} onChange={(e) => updateContact('phone', e.target.value)} />
            <input placeholder="Location" value={resume.contact?.location || ''} onChange={(e) => updateContact('location', e.target.value)} />
            <input placeholder="LinkedIn URL" value={resume.contact?.linkedin || ''} onChange={(e) => updateContact('linkedin', e.target.value)} />
            <input placeholder="GitHub URL" value={resume.contact?.github || ''} onChange={(e) => updateContact('github', e.target.value)} />
          </section>

          <section>
            <h3>Professional Summary <button type="button" className="btn-small" onClick={handleAiImprove} disabled={aiLoading}>{aiLoading ? 'Generating...' : '✨ AI Improve'}</button></h3>
            <textarea rows={4} placeholder="Write or generate a professional summary" value={resume.summary || ''} onChange={(e) => update('summary', e.target.value)} />
          </section>

          <section>
            <h3>Skills</h3>
            <div className="chip-row">
              {resume.skills?.map((s, i) => (
                <span key={i} className="chip">{s} <button onClick={() => removeSkill(i)}>×</button></span>
              ))}
            </div>
            <div className="inline-row">
              <input placeholder="Add a skill" value={skillInput} onChange={(e) => setSkillInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addSkill())} />
              <button type="button" onClick={addSkill}>Add</button>
            </div>
          </section>

          <section>
            <h3>Experience <button type="button" className="btn-small" onClick={() => addItem('experience', emptyExperience)}>+ Add</button></h3>
            {resume.experience?.map((exp, i) => (
              <div key={i} className="repeatable-item">
                <input placeholder="Company" value={exp.company} onChange={(e) => updateItem('experience', i, 'company', e.target.value)} />
                <input placeholder="Role" value={exp.role} onChange={(e) => updateItem('experience', i, 'role', e.target.value)} />
                <input placeholder="Start Date" value={exp.startDate} onChange={(e) => updateItem('experience', i, 'startDate', e.target.value)} />
                <input placeholder="End Date (blank = present)" value={exp.endDate} onChange={(e) => updateItem('experience', i, 'endDate', e.target.value)} />
                <textarea placeholder="Description" value={exp.description} onChange={(e) => updateItem('experience', i, 'description', e.target.value)} />
                <button type="button" className="btn-danger-small" onClick={() => removeItem('experience', i)}>Remove</button>
              </div>
            ))}
          </section>

          <section>
            <h3>Projects <button type="button" className="btn-small" onClick={() => addItem('projects', emptyProject)}>+ Add</button></h3>
            {resume.projects?.map((proj, i) => (
              <div key={i} className="repeatable-item">
                <input placeholder="Title" value={proj.title} onChange={(e) => updateItem('projects', i, 'title', e.target.value)} />
                <input placeholder="Tech Stack" value={proj.techStack} onChange={(e) => updateItem('projects', i, 'techStack', e.target.value)} />
                <input placeholder="Link" value={proj.link} onChange={(e) => updateItem('projects', i, 'link', e.target.value)} />
                <textarea placeholder="Description" value={proj.description} onChange={(e) => updateItem('projects', i, 'description', e.target.value)} />
                <button type="button" className="btn-danger-small" onClick={() => removeItem('projects', i)}>Remove</button>
              </div>
            ))}
          </section>

          <section>
            <h3>Education <button type="button" className="btn-small" onClick={() => addItem('education', emptyEducation)}>+ Add</button></h3>
            {resume.education?.map((edu, i) => (
              <div key={i} className="repeatable-item">
                <input placeholder="Institution" value={edu.institution} onChange={(e) => updateItem('education', i, 'institution', e.target.value)} />
                <input placeholder="Degree" value={edu.degree} onChange={(e) => updateItem('education', i, 'degree', e.target.value)} />
                <input placeholder="Field" value={edu.field} onChange={(e) => updateItem('education', i, 'field', e.target.value)} />
                <input placeholder="Start Year" value={edu.startYear} onChange={(e) => updateItem('education', i, 'startYear', e.target.value)} />
                <input placeholder="End Year" value={edu.endYear} onChange={(e) => updateItem('education', i, 'endYear', e.target.value)} />
                <button type="button" className="btn-danger-small" onClick={() => removeItem('education', i)}>Remove</button>
              </div>
            ))}
          </section>

          <div className="action-row">
            <button onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : 'Save Resume'}</button>
            <button className="btn-secondary" onClick={handleDownload}>Download / Print PDF</button>
          </div>
        </div>

        <div className="builder-preview">
          <ResumePreview resume={resume} />
        </div>
      </div>
    </div>
  );
};

export default ResumeBuilder;

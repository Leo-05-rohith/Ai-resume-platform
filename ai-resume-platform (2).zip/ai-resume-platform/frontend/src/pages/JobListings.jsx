import React, { useEffect, useState } from 'react';
import api from '../api/axios';

const JobListings = () => {
  const [jobs, setJobs] = useState([]);
  const [search, setSearch] = useState('');
  const [location, setLocation] = useState('');
  const [jobType, setJobType] = useState('');
  const [message, setMessage] = useState('');
  const [appliedIds, setAppliedIds] = useState(new Set());

  const fetchJobs = async () => {
    const params = {};
    if (search) params.search = search;
    if (location) params.location = location;
    if (jobType) params.jobType = jobType;
    const res = await api.get('/jobs', { params });
    setJobs(res.data.jobs);
  };

  const fetchMyApplications = async () => {
    try {
      const res = await api.get('/applications/me');
      setAppliedIds(new Set(res.data.applications.map((a) => a.job_id?._id)));
    } catch (e) {
      // ignore if not permitted
    }
  };

  useEffect(() => {
    fetchJobs();
    fetchMyApplications();
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    fetchJobs();
  };

  const handleApply = async (jobId) => {
    setMessage('');
    try {
      await api.post('/applications', { job_id: jobId });
      setAppliedIds((prev) => new Set(prev).add(jobId));
      setMessage('Application submitted!');
    } catch (err) {
      setMessage(err.response?.data?.message || 'Failed to apply');
    }
  };

  return (
    <div className="page">
      <h1>Job Listings</h1>
      {message && <p className="info-text">{message}</p>}

      <form className="filter-row" onSubmit={handleSearch}>
        <input placeholder="Search title, company, skills..." value={search} onChange={(e) => setSearch(e.target.value)} />
        <input placeholder="Location" value={location} onChange={(e) => setLocation(e.target.value)} />
        <select value={jobType} onChange={(e) => setJobType(e.target.value)}>
          <option value="">All Types</option>
          <option value="Full-time">Full-time</option>
          <option value="Part-time">Part-time</option>
          <option value="Internship">Internship</option>
          <option value="Contract">Contract</option>
        </select>
        <button type="submit">Search</button>
      </form>

      <div className="job-list">
        {jobs.length === 0 && <p>No jobs found.</p>}
        {jobs.map((job) => (
          <div key={job._id} className="job-card">
            <h3>{job.title}</h3>
            <p className="job-meta">{job.company} • {job.location} • {job.jobType}</p>
            <p>{job.description}</p>
            <p className="job-skills">{job.skills?.join(', ')}</p>
            <button disabled={appliedIds.has(job._id)} onClick={() => handleApply(job._id)}>
              {appliedIds.has(job._id) ? 'Applied' : 'Apply Now'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default JobListings;

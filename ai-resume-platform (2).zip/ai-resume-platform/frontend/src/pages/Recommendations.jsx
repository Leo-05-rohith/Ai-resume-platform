import React, { useEffect, useState } from 'react';
import api from '../api/axios';

const Recommendations = () => {
  const [loading, setLoading] = useState(true);
  const [recs, setRecs] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    api
      .get('/ai/recommendations')
      .then((res) => setRecs(res.data.recommendations))
      .catch((err) => setError(err.response?.data?.message || 'Failed to load recommendations'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="page">
      <h1>AI Job Recommendations</h1>
      <p>Jobs ranked by how well they match your resume's skills and summary.</p>
      {error && <p className="error-text">{error}</p>}
      {loading && <p>Analyzing your resume against open jobs...</p>}

      <div className="job-list">
        {recs.map(({ job, match }) => (
          <div key={job._id} className="job-card">
            <div className="match-header">
              <h3>{job.title}</h3>
              <span className={`match-score ${match.score >= 70 ? 'high' : match.score >= 40 ? 'mid' : 'low'}`}>
                {match.score}% match
              </span>
            </div>
            <p className="job-meta">{job.company} • {job.location}</p>
            <p>{match.reason}</p>
            {match.matchedSkills?.length > 0 && <p><strong>Matched:</strong> {match.matchedSkills.join(', ')}</p>}
            {match.missingSkills?.length > 0 && <p><strong>Consider learning:</strong> {match.missingSkills.join(', ')}</p>}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Recommendations;

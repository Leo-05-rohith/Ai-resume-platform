import React, { useEffect, useState } from 'react';
import api from '../api/axios';

const emptyForm = { title: '', company: '', location: '', description: '', skills: '', jobType: 'Full-time' };

const AdminJobs = () => {
  const [jobs, setJobs] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [message, setMessage] = useState('');
  const [applications, setApplications] = useState([]);

  const fetchJobs = async () => {
    const res = await api.get('/jobs', { params: { limit: 50 } });
    setJobs(res.data.jobs);
  };

  const fetchApplications = async () => {
    const res = await api.get('/applications');
    setApplications(res.data.applications);
  };

  useEffect(() => {
    fetchJobs();
    fetchApplications();
  }, []);

  const handleChange = (field, value) => setForm({ ...form, [field]: value });

  const resetForm = () => {
    setForm(emptyForm);
    setEditingId(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');
    const payload = { ...form, skills: form.skills.split(',').map((s) => s.trim()).filter(Boolean) };
    try {
      if (editingId) {
        await api.put(`/jobs/${editingId}`, payload);
        setMessage('Job updated.');
      } else {
        await api.post('/jobs', payload);
        setMessage('Job created.');
      }
      resetForm();
      fetchJobs();
    } catch (err) {
      setMessage(err.response?.data?.message || 'Failed to save job');
    }
  };

  const handleEdit = (job) => {
    setEditingId(job._id);
    setForm({
      title: job.title,
      company: job.company,
      location: job.location,
      description: job.description,
      skills: (job.skills || []).join(', '),
      jobType: job.jobType,
    });
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this job posting?')) return;
    await api.delete(`/jobs/${id}`);
    fetchJobs();
  };

  const handleStatusChange = async (appId, status) => {
    await api.put(`/applications/${appId}/status`, { status });
    fetchApplications();
  };

  return (
    <div className="page">
      <h1>Admin: Manage Job Listings</h1>
      {message && <p className="info-text">{message}</p>}

      <form className="admin-form" onSubmit={handleSubmit}>
        <h3>{editingId ? 'Edit Job' : 'Create New Job'}</h3>
        <input placeholder="Title" value={form.title} onChange={(e) => handleChange('title', e.target.value)} required />
        <input placeholder="Company" value={form.company} onChange={(e) => handleChange('company', e.target.value)} required />
        <input placeholder="Location" value={form.location} onChange={(e) => handleChange('location', e.target.value)} />
        <select value={form.jobType} onChange={(e) => handleChange('jobType', e.target.value)}>
          <option value="Full-time">Full-time</option>
          <option value="Part-time">Part-time</option>
          <option value="Internship">Internship</option>
          <option value="Contract">Contract</option>
        </select>
        <input placeholder="Skills (comma-separated)" value={form.skills} onChange={(e) => handleChange('skills', e.target.value)} />
        <textarea placeholder="Description" rows={4} value={form.description} onChange={(e) => handleChange('description', e.target.value)} required />
        <div className="action-row">
          <button type="submit">{editingId ? 'Update Job' : 'Create Job'}</button>
          {editingId && <button type="button" className="btn-secondary" onClick={resetForm}>Cancel</button>}
        </div>
      </form>

      <h3>All Job Postings</h3>
      <table className="table">
        <thead><tr><th>Title</th><th>Company</th><th>Type</th><th>Actions</th></tr></thead>
        <tbody>
          {jobs.map((job) => (
            <tr key={job._id}>
              <td>{job.title}</td>
              <td>{job.company}</td>
              <td>{job.jobType}</td>
              <td>
                <button className="btn-small" onClick={() => handleEdit(job)}>Edit</button>{' '}
                <button className="btn-danger-small" onClick={() => handleDelete(job._id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h3>Applications Received</h3>
      <table className="table">
        <thead><tr><th>Applicant</th><th>Job</th><th>Status</th><th>Update</th></tr></thead>
        <tbody>
          {applications.map((app) => (
            <tr key={app._id}>
              <td>{app.user_id?.name} ({app.user_id?.email})</td>
              <td>{app.job_id?.title}</td>
              <td><span className={`status-badge status-${app.status}`}>{app.status}</span></td>
              <td>
                <select value={app.status} onChange={(e) => handleStatusChange(app._id, e.target.value)}>
                  <option value="applied">Applied</option>
                  <option value="under_review">Under Review</option>
                  <option value="shortlisted">Shortlisted</option>
                  <option value="rejected">Rejected</option>
                  <option value="hired">Hired</option>
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AdminJobs;

import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Dashboard = () => {
  const { user } = useAuth();
  return (
    <div className="page">
      <h1>Welcome, {user?.name}</h1>
      <p>Manage your resume, browse jobs, and get AI-powered recommendations.</p>
      <div className="dashboard-grid">
        <Link className="dashboard-card" to="/resume">📄 Build / Edit Resume</Link>
        <Link className="dashboard-card" to="/jobs">💼 Browse Jobs</Link>
        <Link className="dashboard-card" to="/recommendations">✨ AI Recommendations</Link>
        <Link className="dashboard-card" to="/applications">📋 My Applications</Link>
      </div>
    </div>
  );
};

export default Dashboard;

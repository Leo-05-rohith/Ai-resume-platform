import React, { useEffect, useState } from 'react';
import api from '../api/axios';

const Applications = () => {
  const [applications, setApplications] = useState([]);

  useEffect(() => {
    api.get('/applications/me').then((res) => setApplications(res.data.applications));
  }, []);

  return (
    <div className="page">
      <h1>My Applications</h1>
      {applications.length === 0 && <p>You haven't applied to any jobs yet.</p>}
      <table className="table">
        <thead>
          <tr><th>Job Title</th><th>Company</th><th>Status</th><th>Applied On</th></tr>
        </thead>
        <tbody>
          {applications.map((app) => (
            <tr key={app._id}>
              <td>{app.job_id?.title}</td>
              <td>{app.job_id?.company}</td>
              <td><span className={`status-badge status-${app.status}`}>{app.status}</span></td>
              <td>{new Date(app.applied_at).toLocaleDateString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Applications;
